# \file    peak_opencv.py
# \author  IDS Imaging Development Systems GmbH
# \date    2021-06-21
# \since   1.2.0
#
# \brief   This application demonstrates how to use the device manager to open a camera
#
# \version 1.0.0
#
# Copyright (C) 2021, IDS Imaging Development Systems GmbH.
#
# The information in this document is subject to change without notice
# and should not be construed as a commitment by IDS Imaging Development Systems GmbH.
# IDS Imaging Development Systems GmbH does not assume any responsibility for any errors
# that may appear in this document.
#
# This document, or source code, is provided solely as an example of how to utilize
# IDS Imaging Development Systems GmbH software libraries in a sample application.
# IDS Imaging Development Systems GmbH does not assume any responsibility
# for the use or reliability of any portion of this document.
#
# General permission to copy or modify is hereby granted.



from ids_peak import ids_peak
from ids_peak_ipl import ids_peak_ipl
import numpy as np
import cv2

VERSION = "1.0.0"

def main():
    print("open_camera Sample v" + VERSION)

    # initialize library
    ids_peak.Library.Initialize()

    # create a device manager object
    device_manager = ids_peak.DeviceManager.Instance()

    try:
        # update the device manager
        device_manager.Update()

        # exit program if no device was found
        if device_manager.Devices().empty():
            print("No device found. Exiting Program.")
            return

        # list all available devices
        for i, device in enumerate(device_manager.Devices()):
            print(str(i) + ": " + device.ModelName() + " ("
                  + device.ParentInterface().DisplayName() + "; "
                  + device.ParentInterface().ParentSystem().DisplayName() + "v."
                  + device.ParentInterface().ParentSystem().Version() + ")")

        # select a device to open
        selected_device = None
        while True:
            try:
                selected_device = int(input("Select device to open: "))
                if selected_device in range(len(device_manager.Devices())):
                    break
                else:
                    print("Invalid ID.")
            except ValueError:
                print("Please enter a correct id.")
                continue

        # open selected device
        device = device_manager.Devices()[selected_device].OpenDevice(ids_peak.DeviceAccessType_Control)

        # get the remote device node map
        nodemap_remote_device = device.RemoteDevice().NodeMaps()[0]

        # print model name and user ID
        print("Model Name: " + nodemap_remote_device.FindNode("DeviceModelName").Value())
        print("User ID: " + nodemap_remote_device.FindNode("DeviceUserID").Value())

        # print sensor information, not knowing if device has the node "SensorName"
        try:
            print("Sensor Name: " + nodemap_remote_device.FindNode("SensorName").Value())
        except ids_peak.Exception:
            print("Sensor Name: " + "(unknown)")

        # print resolution
        print("Max. resolution (w x h): "
              + str(nodemap_remote_device.FindNode("WidthMax").Value()) + " x "
              + str(nodemap_remote_device.FindNode("HeightMax").Value()))

        max_fps = nodemap_remote_device.FindNode("AcquisitionFrameRate").Maximum()
        nodemap_remote_device.FindNode("AcquisitionFrameRate").SetValue(max_fps)

        print("Max Framerate: " + str(max_fps))

        # open the data stream
        dataStream = device.DataStreams()[0].OpenDataStream()
        #allocate and announce image buffers
        payloadSize = nodemap_remote_device.FindNode("PayloadSize").Value()
        bufferCountMax = dataStream.NumBuffersAnnouncedMinRequired()
        for bufferCount in range(bufferCountMax):
            buffer = dataStream.AllocAndAnnounceBuffer(payloadSize)
            dataStream.QueueBuffer(buffer)

        # Get image information for opencv image format
        height = nodemap_remote_device.FindNode("Height").Value()
        width = nodemap_remote_device.FindNode("Width").Value()
        cvPixelFormat = cv2.CV_8U
        
        # prepare for untriggered continuous image acquisition
        nodemap_remote_device.FindNode("TriggerSelector").SetCurrentEntry("ExposureStart")
        nodemap_remote_device.FindNode("TriggerMode").SetCurrentEntry("On")
        nodemap_remote_device.FindNode("TriggerSource").SetCurrentEntry("Software")

        # start acquisition
        print("Image acquistion starting...")
        dataStream.StartAcquisition()
        nodemap_remote_device.FindNode("AcquisitionStart").Execute()

        # process the acquired images
        i = 0
        # while i < 100:
        while (True):
            nodemap_remote_device.FindNode("TriggerSoftware").Execute()
            # get buffer from datastream 
            buffer = dataStream.WaitForFinishedBuffer(5000)

            raw_image = ids_peak_ipl.Image_CreateFromSizeAndBuffer(buffer.PixelFormat(), buffer.BasePtr(), buffer.Size(), buffer.Width(), buffer.Height())
            color_image = raw_image.ConvertTo(ids_peak_ipl.PixelFormatName_BGR8) #color format for U3-3680XCP-C
            #color_image = raw_image.ConvertTo(ids_peak_ipl.PixelFormatName_RGB8)
            # frmid = buffer.FrameID()
            # conver to numpy array
            np_image = color_image.get_numpy_3D()
            cv2.imshow('image', np_image)
            cv2.waitKey(1)
            
            # queue buffer
            dataStream.QueueBuffer(buffer)
            #frmid = buffer.FrameID()
            #i+=1
            #print(i)
            #print(frmid)
                        
            
    except Exception as e:
        print("Exception: " + str(e) + "")

    finally:
        input("Press Enter to continue...")
        ids_peak.Library.Close()


if __name__ == '__main__':
    main()
